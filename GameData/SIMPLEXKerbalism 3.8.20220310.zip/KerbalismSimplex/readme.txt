KerbalismSimplex 3.8
version 3.8 - for Kerbalism 3.14


Author: theJesuit, and contributors to KerbalismSimplex

Licence: The Unlicence as per Kerbalism itself

This should be installed as Gamedata/KerbalismSimplex and should include at least KerbalismCore 3.13 installed as Gamedata/Kerbalism

It should NOT be installed with other Kerbalism Profiles such as KerbalismCore.

Community Resource Pack is not required.